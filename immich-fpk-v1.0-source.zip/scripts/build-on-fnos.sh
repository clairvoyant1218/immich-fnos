#!/usr/bin/env bash
set -Eeuo pipefail

# Build the FPK on fnOS (fnpack is supplied by fnOS).  The source tree is
# intentionally kept free of generated archives; artifacts are written to
# dist/ after fnpack has completed.
repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
manifest="$repo_root/manifest"

read_manifest_value() {
    awk -F= -v wanted="$1" '
        { key=$1; gsub(/^[[:space:]]+|[[:space:]]+$/, "", key)
          if (key == wanted) { value=$2; gsub(/^[[:space:]]+|[[:space:]]+$/, "", value); print value; exit } }
    ' "$manifest"
}

[ -f "$manifest" ] || { echo "manifest 不存在：$manifest" >&2; exit 1; }
command -v fnpack >/dev/null 2>&1 || { echo '未找到 fnpack，请在 fnOS 上执行此脚本。' >&2; exit 1; }
command -v tar >/dev/null 2>&1 || { echo '未找到 tar。' >&2; exit 1; }

version="$(read_manifest_value version)"
appname="$(read_manifest_value appname)"
[ -n "$version" ] || { echo 'manifest 缺少 version。' >&2; exit 1; }
[ -n "$appname" ] || { echo 'manifest 缺少 appname。' >&2; exit 1; }

bash "$repo_root/scripts/validate-fpk.sh"

# fnpack emits <appname>.fpk beside the source directory. Remove only this
# generated file and the local artifact directory; source files are preserved.
rm -f "$repo_root/${appname}.fpk"
rm -rf "$repo_root/dist"

# Keep permissions expected by fnOS lifecycle scripts and the UI CGI.
find "$repo_root/cmd" -type f -exec chmod 0700 {} +
[ ! -f "$repo_root/app/ui/index.cgi" ] || chmod 0755 "$repo_root/app/ui/index.cgi"
[ ! -f "$repo_root/app/docker/01-enable-vector.sh" ] || chmod 0755 "$repo_root/app/docker/01-enable-vector.sh"

cd "$repo_root"
fnpack build -d .
[ -f "$repo_root/${appname}.fpk" ] || { echo "fnpack 未生成 ${appname}.fpk。" >&2; exit 1; }

mkdir -p "$repo_root/dist"
artifact="$repo_root/dist/${appname}-${version}.fpk"
mv -f "$repo_root/${appname}.fpk" "$artifact"
if command -v sha256sum >/dev/null 2>&1; then
    (cd "$repo_root/dist" && sha256sum "$(basename "$artifact")" > SHA256SUMS)
else
    (cd "$repo_root/dist" && sha256 "$(basename "$artifact")" > SHA256SUMS)
fi
echo "构建完成：$artifact"
echo "校验文件：$repo_root/dist/SHA256SUMS"
