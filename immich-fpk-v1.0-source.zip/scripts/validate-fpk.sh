#!/usr/bin/env bash
set -Eeuo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
required=(
  manifest
  app/docker/docker-compose.yaml
  app/docker/.env
  app/docker/01-enable-vector.sh
  app/ui/config
  app/ui/images/icon_64.png
  app/ui/images/icon_256.png
  app/config/privilege
  config/privilege
  config/resource
  ICON.PNG
  ICON_256.PNG
  cmd/main
  cmd/immich-bootstrap
  cmd/install_init
  cmd/install_callback
  cmd/uninstall_init
  cmd/uninstall_callback
  cmd/upgrade_init
  cmd/upgrade_callback
)

for rel in "${required[@]}"; do
    [ -f "$repo_root/$rel" ] || { echo "缺少必需文件：$rel" >&2; exit 1; }
done

manifest_value() {
    awk -F= -v wanted="$1" '
      { key=$1; gsub(/^[[:space:]]+|[[:space:]]+$/, "", key)
        if (key == wanted) { value=$2; gsub(/^[[:space:]]+|[[:space:]]+$/, "", value); print value; exit } }
    ' "$repo_root/manifest"
}

[ "$(manifest_value appname)" = immich ] || { echo 'manifest appname 必须为 immich。' >&2; exit 1; }
[ "$(manifest_value version)" = 1.0 ] || { echo 'manifest version 必须为 1.0。' >&2; exit 1; }
[ "$(manifest_value maintainer)" = clairvoyant ] || { echo 'manifest maintainer 必须为 clairvoyant。' >&2; exit 1; }
[ "$(manifest_value distributor)" = clairvoyant ] || { echo 'manifest distributor 必须为 clairvoyant。' >&2; exit 1; }

grep -q '2283:2283' "$repo_root/app/docker/docker-compose.yaml" || { echo 'compose 未声明 2283 端口。' >&2; exit 1; }
grep -q '^STORAGE_ROOT=' "$repo_root/app/docker/.env" || { echo '.env 缺少 STORAGE_ROOT。' >&2; exit 1; }
db_password="$(sed -n 's/^DB_PASSWORD=//p' "$repo_root/app/docker/.env" | head -n1)"
[ "$db_password" = '__GENERATE__' ] || { echo '.env 必须使用 DB_PASSWORD=__GENERATE__ 占位，禁止把运行时密码提交到公开仓库。' >&2; exit 1; }
grep -q '^IMMICH_EXTERNAL_IMPORT_PATHS=' "$repo_root/app/docker/.env" || { echo '.env 缺少 IMMICH_EXTERNAL_IMPORT_PATHS。' >&2; exit 1; }
grep -q 'docker-project' "$repo_root/config/resource" || { echo 'config/resource 缺少 docker-project。' >&2; exit 1; }

echo "FPK 源码校验通过：$(manifest_value appname) v$(manifest_value version)（签名 maintainer=$(manifest_value maintainer)）"
